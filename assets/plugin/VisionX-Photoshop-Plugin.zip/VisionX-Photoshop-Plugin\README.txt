﻿VisionX / Color Blind Guide — Photoshop UXP plugin

1. Unzip this folder.
2. Open Adobe Photoshop (2021+).
3. Plugins → Development → UXP Developer Tool (enable Developer Mode in Preferences → Plugins if needed).
4. Add Plugin → select manifest.json inside this folder.
5. Load, then in Photoshop: Plugins → Color Blind Guide (or VisionX) → Open Panel.

For the browser web tool, open tool.html from the VisionX website project instead.
